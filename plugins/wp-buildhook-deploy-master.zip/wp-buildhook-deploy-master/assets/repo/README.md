# littlebot-netlify Repo Assets #
https://www.justinwhall.com
Copyright (c) 2018 jwind
Licensed under the GPLv2 license.

Assets such as screenshots and banner for WordPress.org plugin repository listing.